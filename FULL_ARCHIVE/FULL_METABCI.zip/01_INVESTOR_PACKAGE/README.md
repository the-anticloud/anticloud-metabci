# 01 Investor Package

**Project:** METABCI
**Upstream:** https://github.com/TBC-TJU/MetaBCI

Content specific to METABCI in category BRAIN_COMPUTER_INTERFACE.
