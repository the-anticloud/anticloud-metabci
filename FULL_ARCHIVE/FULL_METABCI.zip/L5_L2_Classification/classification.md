# L5 L2 Classification — METABCI

**Model:** PAX L5 Narrow L2 General 27B
**Category:** BRAIN_COMPUTER_INTERFACE

This project is classified as a PAX L5 Narrow L2 integration target.
L5: production-ready deployment. L2: general-purpose domain application.

Upstream: https://github.com/TBC-TJU/MetaBCI
