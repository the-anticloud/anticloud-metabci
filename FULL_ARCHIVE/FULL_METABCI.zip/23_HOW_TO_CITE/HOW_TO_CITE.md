# How to Cite — METABCI

**Company:** Anticloud FZ LLE
**Model:** PAX L5 Narrow L2 General 27B
**Project:** METABCI | Category: BRAIN_COMPUTER_INTERFACE
**Upstream:** https://github.com/TBC-TJU/MetaBCI (MIT)

## Overview

This document covers how to cite for the Anticloud integration of METABCI.

Non-invasive BCI open platform

## Anticloud Integration

PAX L5 Narrow L2 General 27B is integrated into METABCI to provide:
- Local AI inference with zero cloud dependency
- AIOSS tamper-evident audit chain
- AES-256 encryption at rest
- Single-binary deployment

## Contact

Lois-Kleinner Alpasan — CEO & CTO, Anticloud FZ LLE
lois@0-1.gg | 0-1.gg
